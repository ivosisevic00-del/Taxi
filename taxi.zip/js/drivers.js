// ================================
// FleetCore ERP
// drivers.js
// ================================

let editingDriver = -1;

function initDrivers() {

    renderDrivers();

    const newBtn = document.getElementById("newDriverBtn");
    const saveBtn = document.getElementById("saveDriver");
    const closeBtn = document.getElementById("closeDriver");

    if (newBtn) {
        newBtn.addEventListener("click", openDriverModal);
    }

    if (saveBtn) {
        saveBtn.addEventListener("click", saveDriver);
    }

    if (closeBtn) {
        closeBtn.addEventListener("click", () => closeModal("driverModal"));
    }

}

function renderDrivers() {

    const tbody = document.getElementById("driversBody");

    if (!tbody) return;

    tbody.innerHTML = "";

    DB.drivers.forEach((driver, index) => {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${driver.name}</td>
            <td>${driver.surname}</td>
            <td>${driver.phone}</td>

            <td>

                <span class="status ${driver.status === "Aktivan" ? "active" : "inactive"}">

                    ${driver.status}

                </span>

            </td>

            <td>

                <button class="editBtn" onclick="editDriver(${index})">

                    <i class="fa-solid fa-pen"></i>

                </button>

                <button class="deleteBtn" onclick="deleteDriver(${index})">

                    <i class="fa-solid fa-trash"></i>

                </button>

            </td>
        `;

        tbody.appendChild(row);

    });

}

function openDriverModal() {

    editingDriver = -1;

    document.getElementById("driverName").value = "";
    document.getElementById("driverSurname").value = "";
    document.getElementById("driverPhone").value = "";
    document.getElementById("driverStatus").value = "Aktivan";

    openModal("driverModal");

}

function saveDriver() {

    const driver = {

        name: document.getElementById("driverName").value.trim(),

        surname: document.getElementById("driverSurname").value.trim(),

        phone: document.getElementById("driverPhone").value.trim(),

        status: document.getElementById("driverStatus").value

    };

    if (driver.name === "") {

        alert("Unesi ime.");

        return;

    }

    if (editingDriver === -1) {

        DB.drivers.push(driver);

        toast("Vozač dodan");

    } else {

        DB.drivers[editingDriver] = driver;

        toast("Vozač ažuriran");

    }

    saveStorage();

    renderDrivers();

    updateDashboard();

    closeModal("driverModal");

}